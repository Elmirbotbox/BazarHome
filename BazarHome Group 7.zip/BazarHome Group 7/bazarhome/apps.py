from django.apps import AppConfig


class BazarhomeConfig(AppConfig):
    name = 'bazarhome'
